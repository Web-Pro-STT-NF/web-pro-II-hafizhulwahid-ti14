<div class="container">
    <img src="https://avatars.githubusercontent.com/u/92196581?v=4" alt="Developer Photo's" class="shadow-lg">
    <h2 class="text-center display-4"><i>@FranssMukti</i></h2>
    <p class="w-50 text-center d-block m-auto">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Expedita sit quo asperiores vel, pariatur consequatur omnis nesciunt repudiandae! Sit numquam tenetur aperiam magni, et illum vel nostrum adipisci aspernatur amet minus eius dolor harum quisquam provident asperiores assumenda iste natus laudantium mollitia pariatur. Obcaecati, excepturi in. In natus dolor ipsum!
    </p>
</div>