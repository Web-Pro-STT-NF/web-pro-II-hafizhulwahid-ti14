<!-- Main Footer -->
<footer class="main-footer">
    <strong>Copyright &copy; 2014-2021 <a href="#">WebAdmin.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 3.1.0
    </div>
</footer>
<!-- ./wrapper -->

<script>
    function hapus(pesan) {
        if (confirm(pesan)){
            return true;
        } else {
            return false;
        }
    }
</script>

</body>

</html>