<?php
    $nama = "Gigih";

    $boolean = true;

    define('phi', 3.14);

    $jari2 = 7;

    $luas = phi * $jari2 * $jari2 ;

    echo "Luas lingkaran adalah" . $luas ;
?>