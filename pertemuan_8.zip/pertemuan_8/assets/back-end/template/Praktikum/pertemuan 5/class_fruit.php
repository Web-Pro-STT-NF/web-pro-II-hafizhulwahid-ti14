
<?php
    class Fruit {
        public $name;
        protected $color;
        private $weight;
    }

?>