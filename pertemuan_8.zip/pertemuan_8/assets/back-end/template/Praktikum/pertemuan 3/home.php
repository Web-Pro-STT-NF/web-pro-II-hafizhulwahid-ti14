<?php
    include_once 'atas.php';
?>
<h1>Welcome Home !!! </h1>
<?php
    require_once 'bawah.php';
?>